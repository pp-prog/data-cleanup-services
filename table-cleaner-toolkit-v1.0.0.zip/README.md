# 脏表格一键清洗工具（自助版）clean_my_table

> 一句话：把一堆乱糟糟的供应商表 / 客户表 / 订单表，**一条命令**洗成能直接用的干净表。
> 不装环境也能先看效果 —— 纯标准库，Python 3.9+ 即可跑。

---

## 30 秒上手

```bash
# 1) 先自检，确认工具本身是好的（16 项断言）
python clean_my_table.py --self-test

# 2) 洗你的表（单个文件或一个目录，.csv / .xlsx 都行）
python clean_my_table.py --input 你的表.csv
python clean_my_table.py --input 一堆表的目录/ --output 结果/

# 3) 打开输出目录
#    clean_master.csv   ← 干净主表
#    needs_review.csv   ← 我修不好的行（都在这，不会消失）
#    report.json        ← 行数对账与问题统计
```

要 xlsx 输出就加 `--format xlsx`，会额外生成 `clean_master.xlsx`（含两个工作表）。

---

## 它到底做了什么

| 能力 | 说明 |
|---|---|
| 自动认表头 | `供应商 / 公司 / Vendor / Company` → 统一成 `name`；中文英文都认 |
| 日期归一 | `2024/1/5`、`2024年1月5日`、`Jan 8 2024` → 统一 `2024-01-05` |
| 金额归一 | `240 USD`、`1.234,56`（欧式）、`1,234.50`（美式）、`(240)`（负数）→ 数值 + 币种 |
| 邮箱校验 | 大小写归一；**非法邮箱不猜**，直接进复核表 |
| 电话清洗 | 去括号去横线去分机，`+81 (0)90-1234-5678 ext.22` → `8109012345678` |
| 币种识别 | `¥` `€` `$` `USD` `CNY` `人民币` → ISO 代码；金额里带符号可推断 |
| 去重合并 | 同名 + 同邮箱/电话视为同一主体，合并并记录合并了几行 |
| 列错位修复 | 未加引号的 `1.234,56` 会被正确还原（而不是错位解析成金额+币种） |
| 复核表 | 缺邮箱、日期解析不了、金额非法 → 全部列出，附原因与源文件行号 |
| 报告 | 行数守恒对账：读入 N 行 → 唯一 M 行 → 合并 N-M 行 |

## 三条原则（和我的定制服务完全一致）

1. **不编造数据** —— 修不好的值不猜，落到 `needs_review.csv` 里让你看见。
2. **不静默丢行** —— 每一行要么进干净表，要么进复核表，行数守恒。
3. **不覆盖原文件** —— 输出永远写到新目录。

---

## 目录结构

```
table-cleaner-toolkit/
├── clean_my_table.py        # 主程序（单文件，仅标准库；读 xlsx 额外需 openpyxl）
├── README.md                # 本文件
├── LICENSE                  # MIT
├── VERSION
└── samples/
    ├── messy_cn_headers.csv     # 中文表头 + 6 种日期 + 4 种金额写法（含一个真 bug）
    ├── vendor_a_equipment.csv
    ├── vendor_b_services.csv
    └── vendor_c_supply.csv
```

## 依赖

- Python 3.9+
- 读 `.xlsx` 需 `pip install openpyxl`；纯 CSV 不需要任何第三方库

## 许可

MIT —— 可自由用于个人与商业场景。二次分发请保留本文件与 LICENSE。
